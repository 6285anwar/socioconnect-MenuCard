function options_popup(){

    var modal = document.getElementById("pop_up");
    
    modal.style.display = "block";
  
  }
  function close_popup(){
  
    var modal = document.getElementById("pop_up");
    
    modal.style.display = "none";
  
}